#include <stdio.h>
#include <iostream>
#include <cmath>


class Linear_solve{
private:
    unsigned int size;
    unsigned int row_size;
    double* A;
    int max_iteration = 10000;
public:
    
    Linear_solve(double *array, unsigned int n);
    void solve(double *target, double *soln);
};

Linear_solve::Linear_solve(double *array, unsigned int n){
    size = n;
    row_size = n;
    A = array;
}


void Linear_solve::solve(double *target, double *soln){
    for (int i{0}; i < max_iteration; i++) {
        double old_u[size];
        for (int j{0}; j < size; j++) {
            old_u[j] = soln[j];
        }
        
        for (int k{0}; k < size; k++) {
            soln[k] = target[k];
            for (int m{0}; m < size; m++){
                if (m != k){
                    soln[k] -= A[size*k + m]*soln[m];
                }
            }
            soln[k] /= A[k*size + k];
        }
        
        double norm{0};
        for (int n{0}; n < size; n++) {
            double difference{0};
            difference = soln[n] - old_u[n];
            norm += pow(difference, 2);
        }
        
        if (sqrt(norm) < 10e-13) {
            return;
        }
    }
}
